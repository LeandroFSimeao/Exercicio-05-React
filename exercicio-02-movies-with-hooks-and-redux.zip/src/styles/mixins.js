const spacings = (padding, margin = "inherit") => `
	padding: ${padding};
	margin: ${margin};
`;

export { spacings };
