export const variables = {
	primaryColor: "#eee",
}