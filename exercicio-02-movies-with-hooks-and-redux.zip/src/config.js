export const configs = {
	API_URL_BASE: "https://api.themoviedb.org/3/",
	API_KEY: "d416af5d4faee64e25ab001d87aab5c3",
};
